package com.search;

import com.bill.connection.ConnectionString_info;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

public class searchDAO {

    public List<TestModel> FirstName_Search(String fname,List<TestModel> list) {
        try {
            Connection con = ConnectionString_info.connectme();
            String sql = "select * from customerinfo where First_Name like?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, fname);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
//                System.out.println("First Name " + fname + "      " + rs.getString("Surname"));
                TestModel model = new TestModel();
                model.setId(rs.getInt(2));
                model.setFName(rs.getString(3));
                model.setMName(rs.getString(4));
                model.setLName(rs.getString(5));
                model.setRegisteredDate(rs.getDate(9));
                list.add(model);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<TestModel> MiddleName_Search(String mname,List<TestModel> list) {
        try {
            Connection con = ConnectionString_info.connectme();
            String sql = "select * from customerinfo where Middle_Name like?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, mname);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
//                System.out.println("Middle Name " + mname + "      " + rs.getString("Surname"));
            TestModel model = new TestModel();
                model.setId(rs.getInt(2));
                model.setFName(rs.getString(3));
                model.setMName(rs.getString(4));
                model.setLName(rs.getString(5));
                model.setRegisteredDate(rs.getDate(9));
                list.add(model);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<TestModel> LastName_Search(String sname,List<TestModel> list) {
        try {
            Connection con = ConnectionString_info.connectme();
            String sql = "select * from customerinfo where Surname  like?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, sname);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
//                System.out.println("Last Name " + sname + "      " + rs.getString("Surname"));
                TestModel model = new TestModel();
               model.setId(rs.getInt(2));
                model.setFName(rs.getString(3));
                model.setMName(rs.getString(4));
                model.setLName(rs.getString(5));
                model.setRegisteredDate(rs.getDate(9));
                list.add(model);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<TestModel> Date_Search(Date Search_date,List<TestModel> list) {
        try {
            Connection con = ConnectionString_info.connectme();
            String sql = "select * from customerinfo where Registered_date =?";
            PreparedStatement pst = con.prepareStatement(sql);
            java.sql.Date sqlStartDate = new java.sql.Date(Search_date.getTime());
            pst.setDate(1, sqlStartDate);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
//                System.out.println( Search_date + "      " + rs.getString("First_Name"));
                TestModel model = new TestModel();
               model.setId(rs.getInt(2));
                model.setFName(rs.getString(3));
                model.setMName(rs.getString(4));
                model.setLName(rs.getString(5));
                model.setRegisteredDate(rs.getDate(9));
                list.add(model);
            }
        } catch (Exception e) {
            System.out.println("err" + e);
        }
        return list;
    }

    public List<TestModel> CusID_Search(int CusId,List<TestModel> list) {
        try {
            Connection con = ConnectionString_info.connectme();
            String sql = "select * from customerinfo where Customer_Id =?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, CusId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
//                System.out.println("Last Name " + CusId + "      " + rs.getString("First_Name"));
                TestModel model = new TestModel();
                model.setId(rs.getInt(2));
                model.setFName(rs.getString(3));
                model.setMName(rs.getString(4));
                model.setLName(rs.getString(5));
                model.setRegisteredDate(rs.getDate(9));
                list.add(model);
            }
        } catch (Exception e) {
        }
        return list;
    }

}
