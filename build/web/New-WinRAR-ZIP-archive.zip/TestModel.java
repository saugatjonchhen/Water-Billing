/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.search;

import java.util.Date;

/**
 *
 * @author Saroj
 */
public class TestModel {
    private String FName;
    private String MName;
    private String LName;
    private Date RegisteredDate;
    private int id;

    /**
     * @return the FName
     */
    public String getFName() {
        return FName;
    }

    /**
     * @param FName the FName to set
     */
    public void setFName(String FName) {
        this.FName = FName;
    }

    /**
     * @return the MName
     */
    public String getMName() {
        return MName;
    }

    /**
     * @param MName the MName to set
     */
    public void setMName(String MName) {
        this.MName = MName;
    }

    /**
     * @return the LName
     */
    public String getLName() {
        return LName;
    }

    /**
     * @param LName the LName to set
     */
    public void setLName(String LName) {
        this.LName = LName;
    }

    /**
     * @return the RegisteredDate
     */
    public Date getRegisteredDate() {
        return RegisteredDate;
    }

    /**
     * @param RegisteredDate the RegisteredDate to set
     */
    public void setRegisteredDate(Date RegisteredDate) {
        this.RegisteredDate = RegisteredDate;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
